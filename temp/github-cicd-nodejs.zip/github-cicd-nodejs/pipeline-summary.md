# GitHub Actions Pipeline 总结

本文总结当前项目中的 GitHub Actions pipeline 设计、执行流程、数据传递方式、自定义 Action 以及与 GitLab CI/CD 的概念映射。

## 1. Pipeline 文件结构

```text
.github/
├── workflows/
│   ├── ci.yml                  # 持续集成：Lint、测试、构建和结果汇总
│   ├── cd.yml                  # 持续部署：构建镜像、Staging、Production 和失败通知
│   ├── reusable-deploy.yml     # 可复用部署 workflow
│   └── scheduled-cleanup.yml   # 定时维护和手动维护任务
└── actions/
    ├── setup-node-cached/
    │   └── action.yml          # Node.js、npm cache 和 npm ci 的 Composite Action
    └── custom-actions-examples/
        ├── composite/action.yml
        ├── javascript/action.yml
        ├── javascript/index.js
        └── docker/
            ├── action.yml
            ├── Dockerfile
            └── entrypoint.sh
```

整体执行模型：

```text
事件
 ├── push / pull_request ──> CI workflow
 ├── push main / 手动触发 ──> CD workflow
 └── schedule / 手动触发 ──> Scheduled Maintenance workflow

CI: lint + test ──> build ──> summary
CD: build-image ──> deploy-staging ──> deploy-production
                              └────────────> notify-failure
```

## 2. CI Workflow

文件：[.github/workflows/ci.yml](.github/workflows/ci.yml)

### 2.1 触发条件

| 触发器 | 行为 |
|---|---|
| `push` | 任意分支 push 时触发。 |
| `pull_request` | 只处理目标为 `main` 的 Pull Request。 |
| `paths-ignore` | 只修改 Markdown 或 `docs/` 内容时跳过 CI。 |
| Pull Request types | 在 `opened`、`synchronize`、`reopened` 时运行。 |

### 2.2 全局配置

- `NODE_VERSION_DEFAULT`：默认 Node.js 版本为 20。
- `ARTIFACT_RETENTION_DAYS`：artifact 保留 7 天。
- `concurrency`：同一个 workflow/ref 的新运行会取消旧运行，减少重复消耗。

### 2.3 Job 流程

#### `lint`

执行代码质量检查：

1. `actions/checkout@v4` 检出源代码。
2. 调用本地 `setup-node-cached` Composite Action。
3. 执行 `npm run lint`。
4. 执行 `npm run format:check`。

#### `test`

使用 matrix 在三个 Node.js 版本上并行测试：

```yaml
strategy:
  matrix:
    node-version: ['18', '20', '22']
  fail-fast: false
```

每个矩阵组合执行：

1. 检出代码。
2. 安装对应 Node.js 和 npm 依赖。
3. 执行 `npm run test:coverage`。
4. 只有 Node.js 20 的组合上传 `coverage/` artifact，避免重复上传三份报告。

#### `build`

```yaml
needs: [lint, test]
```

`build` 必须等待 `lint` 和所有 `test` 矩阵组合完成后才运行。该 job：

1. 检出代码并安装依赖。
2. 使用 `NODE_ENV=production` 执行 `npm run build`。
3. 将 `dist/` 上传为 `dist-${{ github.sha }}` artifact。
4. `if-no-files-found: error` 确保构建没有静默产生空产物。

#### `summary`

```yaml
needs: [lint, test, build]
if: always()
```

无论上游 job 成功还是失败，都生成 GitHub Job Summary，展示：

- Lint 状态。
- Test 状态。
- Build 状态。
- Commit SHA。
- 分支和触发者。

输出位置由 `$GITHUB_STEP_SUMMARY` 控制，可在 Actions 页面查看。

### 2.4 CI 依赖图

```text
lint ──┐
       ├──> build ──> summary
test ──┘          
```

没有 `needs` 的 `lint` 和 `test` 会并行执行；`build` 等待两者；`summary` 最后汇总结果。

## 3. CD Workflow

文件：[.github/workflows/cd.yml](.github/workflows/cd.yml)

### 3.1 触发条件

| 触发器 | 行为 |
|---|---|
| `push` 到 `main` | 进入标准部署流程。 |
| `workflow_dispatch` | 手动选择 `staging` 或 `production`。 |
| `target_env` | 手动触发时选择部署目标环境。 |
| `skip_staging` | 手动触发时允许跳过 Staging，适用于紧急修复场景。 |
| `paths-ignore` | 只修改 Markdown 或 `docs/` 时跳过 CD。 |

### 3.2 权限和变量

workflow 使用最小化的基础权限：

```yaml
permissions:
  contents: read
  packages: write
  deployments: write
```

主要配置：

| 类型 | 名称 | 用途 |
|---|---|---|
| Environment variable | `REGISTRY` | 镜像仓库，当前为 `ghcr.io`。 |
| Environment variable | `IMAGE_NAME` | 使用 `${{ github.repository }}` 作为镜像名称。 |
| Repository secret | `DEPLOY_TOKEN` | 调用部署系统所需的鉴权 Token。 |
| Repository secret | `SLACK_WEBHOOK_URL` | Slack 通知地址。 |
| Repository variable | `DEPLOY_URL_STAGING` | Staging 部署 URL。 |
| Repository variable | `DEPLOY_URL_PROD` | Production 部署 URL。 |
| Environment | `staging` | 通常无需审批，可限制 main 分支。 |
| Environment | `production` | 配置 Required reviewers 和等待时间。 |

### 3.3 `build-image`

该 job 负责构建并推送 Docker 镜像：

1. 检出源代码。
2. 尝试下载 CI 生成的 `dist-${{ github.sha }}` artifact。
3. 如果本次 CD run 中不存在构建产物，则执行 fallback build。
4. 使用 `docker/setup-buildx-action@v3` 初始化 Buildx。
5. 登录 GHCR。
6. 使用 `docker/metadata-action@v5` 生成镜像标签。
7. 使用 `docker/build-push-action@v5` 构建并推送镜像。
8. 构建 `linux/amd64` 和 `linux/arm64` 多平台镜像。
9. 使用 GitHub Actions Cache 缓存 Docker layers。

输出：

| Output | 来源 | 用途 |
|---|---|---|
| `image-tag` | `steps.meta.outputs.tags` | 传递镜像标签。 |
| `image-digest` | `steps.build-push.outputs.digest` | 通过不可变 digest 精确识别镜像版本。 |

### 3.4 `deploy-staging`

该 job 依赖 `build-image`，并使用 GitHub Environment `staging`：

1. 调用 Staging 部署 webhook。
2. 通过环境变量注入 `DEPLOY_TOKEN`。
3. 检查 `/health` endpoint 是否返回 HTTP 200。
4. 通过 Slack 发送成功或失败通知。

当前健康检查先固定等待 10 秒，再执行一次检查；生产项目通常建议改成带超时和重试次数的轮询逻辑。

### 3.5 `deploy-production`

该 job 依赖：

```yaml
needs: [build-image, deploy-staging]
```

它调用 [reusable-deploy.yml](.github/workflows/reusable-deploy.yml)，并传入：

- `environment`
- `image_tag`
- `image_digest`
- `deploy_token`
- `slack_webhook`

Production 的审批由 GitHub Environment 的 Required reviewers 控制。标准 push 流程要求 Staging 成功后再进入 Production；手动选择 Production 或设置跳过 Staging 时，可以走紧急部署路径。

### 3.6 `notify-failure`

```yaml
needs: [deploy-staging, deploy-production]
if: failure()
```

当部署链路中的相关 job 失败时，发送 Slack 失败通知，并附带：

- 仓库。
- 分支。
- 触发者。
- Actions run URL。

### 3.7 CD 依赖图

```text
build-image ────────────────┐
                            ├──> deploy-production ──┐
deploy-staging ─────────────┘                        ├──> notify-failure（失败时）
```

标准 main push 的实际路径为：

```text
build-image -> deploy-staging -> Production approval -> deploy-production
```

## 4. Reusable Deploy Workflow

文件：[.github/workflows/reusable-deploy.yml](.github/workflows/reusable-deploy.yml)

该 workflow 没有 `push` 或 `schedule` 触发器，只能通过 `workflow_call` 被其他 workflow 调用。

### 4.1 输入参数

| Input | 必填 | 作用 |
|---|---:|---|
| `environment` | 是 | `staging` 或 `production`。 |
| `image_tag` | 是 | 待部署镜像标签。 |
| `image_digest` | 否 | 镜像 digest，默认空字符串。 |
| `deploy_url_override` | 否 | 调试或特殊场景下覆盖部署 URL。 |

### 4.2 Secrets

| Secret | 必填 | 作用 |
|---|---:|---|
| `deploy_token` | 是 | 调用部署服务的 Bearer Token。 |
| `slack_webhook` | 否 | 部署结果通知地址。 |

### 4.3 输出

| Output | 来源 | 作用 |
|---|---|---|
| `deploy_url` | `jobs.deploy.outputs.deploy_url` | 返回实际部署 URL。 |
| `deployed_at` | `jobs.deploy.outputs.deployed_at` | 返回部署完成时间。 |

### 4.4 执行步骤

1. **Resolve deploy URL**：优先使用 override URL，否则按环境读取仓库 variables。
2. **Deploy**：向部署系统发送镜像标签、digest、环境、commit 和 run URL。
3. **Wait for service to be ready**：最多重试 12 次，每次间隔 10 秒，等待 `/health` 返回 200。
4. **Write deployment summary**：写入 Job Summary。
5. **Notify Slack**：发送成功或失败通知。

该 workflow 展示了完整的数据流：

```text
调用方 job
  ├── with.environment
  ├── with.image_tag
  ├── with.image_digest
  └── secrets.deploy_token / secrets.slack_webhook
          │
          ▼
reusable-deploy.yml
  ├── step outputs: resolve-url、deploy
  ├── job outputs: deploy_url、deployed_at
  └── workflow outputs: 返回给调用方
```

## 5. Scheduled Maintenance Workflow

文件：[.github/workflows/scheduled-cleanup.yml](.github/workflows/scheduled-cleanup.yml)

### 5.1 触发方式

| 触发器 | 行为 |
|---|---|
| `schedule` | 每天 UTC 02:00 执行，即北京时间 10:00。 |
| `workflow_dispatch` | 手动执行，并支持 `dry_run` 和 `tasks` 输入。 |

### 5.2 Job 流程

#### `cleanup-images`

- 只授予 `packages: write` 权限。
- 根据 `DRY_RUN` 决定是否实际清理镜像。
- 将删除数量写入 `$GITHUB_OUTPUT`。
- 通过 job output 暴露 `deleted_count`。

#### `daily-report`

依赖 `cleanup-images`，通过以下表达式读取上游结果：

```yaml
${{ needs.cleanup-images.outputs.deleted_count }}
```

然后写入每日维护报告，包括：

- 删除的镜像数量。
- DRY RUN 或 LIVE 模式。
- 触发方式。

## 6. 本地自定义 Actions

### 6.1 `setup-node-cached` Composite Action

文件：[.github/actions/setup-node-cached/action.yml](.github/actions/setup-node-cached/action.yml)

这是项目中实际被 CI 使用的本地 Composite Action，封装了：

1. 使用 `actions/setup-node@v4` 安装指定 Node.js。
2. 启用 npm cache。
3. 执行 `npm ci`。

输入参数：

| Input | 默认值 | 作用 |
|---|---|---|
| `node-version` | `20` | Node.js 版本。 |
| `working-directory` | `.` | npm 项目目录。 |
| `install-args` | 空 | 传递给 `npm ci` 的额外参数。 |

输出参数：

| Output | 作用 |
|---|---|
| `cache-hit` | 表示 npm cache 是否命中。 |
| `node-version` | 返回实际安装的 Node.js 版本。 |

调用方式：

```yaml
- uses: ./.github/actions/setup-node-cached
  with:
    node-version: '20'
```

### 6.2 Composite Action 示例

文件：[.github/actions/custom-actions-examples/composite/action.yml](.github/actions/custom-actions-examples/composite/action.yml)

特点：

- 使用 YAML 定义。
- 可以组合多个现有 step、Action 和 shell 命令。
- 无需额外编译。
- 适合封装组织内的标准操作。

该示例接收 `message`，打印消息，并通过 `$GITHUB_OUTPUT` 返回 `result`。

### 6.3 JavaScript Action 示例

文件：[.github/actions/custom-actions-examples/javascript/action.yml](.github/actions/custom-actions-examples/javascript/action.yml)

实现文件：[.github/actions/custom-actions-examples/javascript/index.js](.github/actions/custom-actions-examples/javascript/index.js)

特点：

- 使用 `node20` 运行。
- 从 `INPUT_MESSAGE` 读取输入。
- 使用 Node.js 处理消息。
- 将结果写入 `$GITHUB_OUTPUT`。
- 适合需要文件、网络、API 或复杂编程逻辑的 Action。

### 6.4 Docker Action 示例

文件：[.github/actions/custom-actions-examples/docker/action.yml](.github/actions/custom-actions-examples/docker/action.yml)

相关文件：

- [Dockerfile](.github/actions/custom-actions-examples/docker/Dockerfile)
- [entrypoint.sh](.github/actions/custom-actions-examples/docker/entrypoint.sh)

特点：

- 使用 Alpine 容器运行。
- 安装 `findutils`。
- 统计指定目录中的文件数量。
- 通过 `$GITHUB_OUTPUT` 输出 `file-count`。
- 适合需要固定运行时或非 Node.js 语言环境的工具。

三种 Action 类型对比：

| 类型 | 实现方式 | 优点 | 适用场景 |
|---|---|---|---|
| Composite | YAML + shell/现有 Actions | 简单、启动快、无需编译 | 标准步骤组合。 |
| JavaScript | Node.js | 灵活、跨平台、适合 API 和文件处理 | 复杂逻辑和平台集成。 |
| Docker | Dockerfile + entrypoint | 运行环境固定、语言无关 | 特定依赖、CLI 工具和非 Node.js 运行时。 |

## 7. 项目中的数据传递方式

| 方式 | 作用范围 | 当前示例 |
|---|---|---|
| `env` | workflow、job 或 step | Node 版本、部署 URL、`NODE_ENV`。 |
| `$GITHUB_OUTPUT` | step output | 清理数量、镜像 digest、部署时间。 |
| job `outputs` | 下游 job 或调用方 workflow | `image-tag`、`image-digest`、`deleted_count`。 |
| `$GITHUB_STEP_SUMMARY` | 当前 job 的 Actions 页面 | CI、部署和维护报告。 |
| Artifact | workflow run 中的文件 | `coverage-report`、`dist-${{ github.sha }}`。 |
| Cache | 后续运行的性能缓存 | npm cache、Docker layer cache。 |
| `secrets` | 受保护的敏感值 | 部署 Token、Slack Webhook。 |
| `vars` | 非敏感配置 | Staging 和 Production URL。 |

重要区别：

- `needs` 负责控制顺序和读取 job outputs，不负责自动传递文件。
- 文件需要通过 `upload-artifact` 和 `download-artifact` 传递。
- `$GITHUB_ENV` 只影响当前 job 的后续 steps。
- Cache 用于加速，不应作为可靠的构建产物传输机制。

## 8. 与 GitLab CI/CD 的主要映射

| GitLab CI/CD | GitHub Actions |
|---|---|
| `.gitlab-ci.yml` | `.github/workflows/*.yml` |
| pipeline | workflow run |
| `stages` | `needs` 组成的 DAG；没有顶层 stages 字段 |
| `script` | step 的 `run` |
| `before_script` / `after_script` | 独立的前置/后置 steps |
| `image` | job `container` |
| Runner `tags` | `runs-on` 和 Runner labels |
| `rules` | `on` + job/step `if` |
| `needs` | `needs` |
| `artifacts` | upload/download-artifact |
| `dependencies` | `needs` + download-artifact |
| `cache` | actions/cache 或 Action 内置 cache |
| `variables` | `env`、`vars`、`secrets` |
| `allow_failure` | `continue-on-error` |
| `parallel:matrix` | `strategy.matrix` |
| `environment` | `environment` |
| `resource_group` | `concurrency.group` |
| `trigger` | reusable workflow、`workflow_run` 或 dispatch |
| `include` / `extends` | reusable workflow、Composite Action、Marketplace Action |
| `when: manual` | `workflow_dispatch` 或 environment approval |
| `pages` | Pages artifact + deploy action |

## 9. 当前实现的优点

1. CI、CD、定时维护职责分离，便于独立运行和权限控制。
2. CI 使用 matrix 覆盖多个 Node.js 版本。
3. `build` 明确依赖 `lint` 和 `test`，执行关系清晰。
4. 使用 artifact 传递 coverage 和构建产物。
5. 使用 SHA、tag 和 digest 标识 Docker 镜像，支持版本追踪。
6. CD 支持多平台镜像构建。
7. Production 使用 Environment 审批机制保护。
8. 部署逻辑通过 reusable workflow 封装，减少重复代码。
9. 自定义 Composite Action 统一 Node.js 安装、缓存和依赖安装。
10. 使用 Job Summary 和 Slack 提供结果可见性。
11. 各类 workflow 使用了不同的触发器、outputs、secrets、matrix 和服务化能力示例。

## 10. 生产化时建议关注的事项

### 10.1 跨 workflow artifact

当前 `ci.yml` 和 `cd.yml` 是两个独立 workflow。`cd.yml` 中的普通 `download-artifact` 默认针对当前 workflow run；因此它通常无法直接下载另一个 CI workflow run 产生的 artifact。

当前代码已经提供 fallback build，但生产项目可以进一步选择：

- 在同一个 workflow 中完成 CI 和 CD。
- 使用 artifact API 按 SHA 查找并下载 CI run 的 artifact。
- 直接在 CD 中重新构建，并将镜像作为唯一部署制品。
- 通过 workflow 触发事件传递明确的 run ID。

### 10.2 Shell 注入和外部输入

工作流中使用了 `github.actor`、手动输入、变量和 webhook URL。生产环境应：

- 避免把不可信输入直接拼接到 shell 命令。
- 优先通过 `env` 传递输入。
- 对 JSON 请求使用安全的序列化方式。
- 对 URL、环境名和镜像标签进行白名单校验。

### 10.3 Action 版本固定

当前示例使用 `@v3`、`@v4`、`@v5` 等 major version 标签，学习和普通项目中较方便。高安全等级项目可以固定到 commit SHA，并定期更新和审查 Action。

### 10.4 部署健康检查

`reusable-deploy.yml` 已使用循环重试健康检查，这是更适合生产的方式。`cd.yml` 的 Staging 检查仍是固定等待后单次检查，建议统一为：

- 最大等待时间。
- 单次请求超时。
- 重试间隔。
- 失败时输出最近响应和诊断信息。

### 10.5 权限最小化

建议继续保持：

- workflow 默认 `contents: read`。
- 只在推送 GHCR 的 job 使用 `packages: write`。
- 只在创建部署记录的 job 使用 `deployments: write`。
- 定时清理 job 只授予必要的 `packages: write`。
- 对来自 Fork 的 Pull Request 不授予不必要的写权限。

## 11. 总结

当前项目展示了一条完整的 GitHub Actions 学习型 pipeline：

```text
CI
  ├── Lint
  ├── Node 18/20/22 矩阵测试
  ├── Build dist artifact
  └── Job Summary

CD
  ├── 下载或重新构建产物
  ├── 构建并推送 GHCR 多平台镜像
  ├── 部署 Staging 并健康检查
  ├── Production Environment 审批
  ├── 调用 reusable deploy workflow
  └── 失败 Slack 通知

Maintenance
  ├── Cron 定时执行
  ├── workflow_dispatch 手动执行
  ├── DRY RUN
  ├── job outputs
  └── 每日报告
```

对于熟悉 GitLab CI/CD 的使用者，可以将其理解为：

```text
GitLab pipeline
  ≈ GitHub workflow run

GitLab stages + needs
  ≈ GitHub jobs + needs DAG

GitLab script
  ≈ GitHub steps.run

GitLab image
  ≈ GitHub jobs.<job_id>.container

GitLab artifacts
  ≈ GitHub upload-artifact/download-artifact

GitLab variables
  ≈ GitHub env / vars / secrets / contexts

GitLab include + extends
  ≈ GitHub reusable workflow + Composite Action
```
